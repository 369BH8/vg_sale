import streamlit as st 

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv("train.csv", index_col= 0)

df = df.drop(df.select_dtypes("object").columns, axis = 1)
df = df.fillna(df.mean())

X = df.drop("Survived", axis=1)
y = df["Survived"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=123)

models = ["logreg", "knn", "RandomForest"]

def get_score(model):
    if model == models[0]:
        m = LogisticRegression()
    if model == models[1]:
        m = KNeighborsClassifier()
    if model == models[2]:
        m = RandomForestClassifier()
    
    m.fit(X_train, y_train)
    return m.score(X_test, y_test)

st.sidebar.title("Navigation")

pages = ["Presentation", "Data Viz", "Modeling"]

page = st.sidebar.radio("Choose a page", pages)

if page == pages[0]:

    st.title("My titanic project")
    st.header("a machine learning project")
    st.subheader("By the Datascientest team")

    st.image("image.jpg")

    st.markdown("This is my [dataframe](https://www.kaggle.com/competitions/titanic/overview):")

    st.dataframe(df.head())

if page == pages[1]:

    fig = plt.figure()

    sns.countplot(x="Survived", data=df)

    st.pyplot(fig)

if page == pages[2]:

    model = st.selectbox("Choose a model to train: ", models)

    st.write("Model score: ", get_score(model))

